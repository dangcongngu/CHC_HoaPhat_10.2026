-- =====================================================================================
-- Lượm Lúa tool - cấu trúc database trên Supabase
-- Một danh sách duy nhất, không đăng nhập. App truy cập qua các hàm (RPC) và "mã truy cập".
--
-- CÁCH CHẠY: Supabase Dashboard -> SQL Editor -> New query -> dán TOÀN BỘ file này -> Run.
-- Sau đó ĐỔI mã truy cập ở cuối file (dòng "select public.set_access_key(...)") trước khi chạy,
-- rồi nhập đúng mã đó vào app (tab "Kết nối Supabase").
-- File chạy lại nhiều lần được (không mất dữ liệu).
-- =====================================================================================

create extension if not exists pgcrypto with schema extensions;

-- ------------------------------------------------------------------ Bảng dữ liệu
create table if not exists public.patients (
  id            uuid primary key default gen_random_uuid(),
  stt           integer,
  ma_nv         text not null unique,          -- luôn lưu IN HOA, bỏ khoảng trắng đầu/cuối
  ho_ten        text not null,
  gioi_tinh     text,
  ngay_sinh     date,
  tuoi          integer,
  cong_ty       text,
  cccd          text,                          -- text để không mất số 0 đầu
  qr_code       text,
  don_nhan_ap   text,                          -- giữ nguyên giá trị Excel ("x" hoặc rỗng) để thống kê sau
  dien_tim      text,
  extra         jsonb not null default '{}'::jsonb,   -- các cột Excel còn lại (ví dụ Năm sinh)
  examined_at   timestamptz,                   -- thời điểm đã khám (check-in)
  examined_by   text,
  submitted_at  timestamptz,                   -- thời điểm nộp hồ sơ (check-out)
  submitted_by  text,
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now()
);
-- Ngày khám / ngày nộp hồ sơ theo GIỜ VIỆT NAM (tự tính từ examined_at / submitted_at) để lọc và thống kê theo ngày.
-- Ví dụ: select examined_date, count(*) from patients where examined_date is not null group by 1 order by 1;
alter table public.patients
  add column if not exists examined_date  date generated always as ((examined_at  at time zone 'Asia/Ho_Chi_Minh')::date) stored,
  add column if not exists submitted_date date generated always as ((submitted_at at time zone 'Asia/Ho_Chi_Minh')::date) stored;
-- Loại bệnh nhân: "Khám Nghề Nghiệp" hoặc "Khám Định Kỳ" (cột "Loại BN" trong Excel).
alter table public.patients add column if not exists loai_bn text;
create index if not exists patients_examined_date_idx  on public.patients (examined_date);
create index if not exists patients_submitted_date_idx on public.patients (submitted_date);

create index if not exists patients_updated_at_idx on public.patients (updated_at);
create index if not exists patients_stt_idx        on public.patients (stt);
create index if not exists patients_cccd_idx       on public.patients (cccd);

create table if not exists public.app_settings (
  key   text primary key,
  value text not null
);

-- Chặn mọi truy cập trực tiếp vào bảng bằng khóa công khai: chỉ đi qua các hàm bên dưới.
alter table public.patients     enable row level security;
alter table public.app_settings enable row level security;
revoke all on public.patients     from anon, authenticated;
revoke all on public.app_settings from anon, authenticated;

-- ------------------------------------------------------------------ Mã truy cập
create or replace function public.set_access_key(p_key text) returns void
language plpgsql security definer set search_path = public, extensions as $$
begin
  if p_key is null or length(btrim(p_key)) < 6 then
    raise exception 'Mã truy cập phải có ít nhất 6 ký tự';
  end if;
  insert into app_settings (key, value) values ('access_key_hash', crypt(btrim(p_key), gen_salt('bf')))
  on conflict (key) do update set value = excluded.value;
end $$;

create or replace function public.fn_check_key(p_key text) returns void
language plpgsql security definer set search_path = public, extensions as $$
declare h text;
begin
  select value into h from app_settings where key = 'access_key_hash';
  if h is null then
    raise exception 'Chưa thiết lập mã truy cập trên Supabase (chạy select public.set_access_key(''mã của bạn''))' using errcode = '28000';
  end if;
  if p_key is null or crypt(btrim(p_key), h) <> h then
    perform pg_sleep(0.5);                       -- làm chậm việc dò mã
    raise exception 'Sai mã truy cập' using errcode = '28000';
  end if;
end $$;

-- ------------------------------------------------------------------ Đọc dữ liệu
create or replace function public.list_patients(p_key text) returns jsonb
language plpgsql security definer set search_path = public, extensions as $$
begin
  perform fn_check_key(p_key);
  return jsonb_build_object(
    'server_time', now(),
    'rows', coalesce((select jsonb_agg(to_jsonb(p) order by p.stt nulls last, p.ma_nv) from patients p), '[]'::jsonb));
end $$;

-- Các dòng thay đổi kể từ p_since (app gọi định kỳ để cập nhật dữ liệu mới)
create or replace function public.get_changes(p_key text, p_since timestamptz) returns jsonb
language plpgsql security definer set search_path = public, extensions as $$
begin
  perform fn_check_key(p_key);
  return jsonb_build_object(
    'server_time', now(),
    'rows', coalesce((select jsonb_agg(to_jsonb(p)) from patients p where p.updated_at > p_since), '[]'::jsonb));
end $$;

create or replace function public.get_stats(p_key text) returns jsonb
language plpgsql security definer set search_path = public, extensions as $$
begin
  perform fn_check_key(p_key);
  return (select jsonb_build_object(
    'total',        count(*),
    'examined',     count(*) filter (where examined_at  is not null),
    'submitted',    count(*) filter (where submitted_at is not null),
    'don_nhan_ap',  count(*) filter (where nullif(btrim(don_nhan_ap), '') is not null),
    'dien_tim',     count(*) filter (where nullif(btrim(dien_tim), '')    is not null),
    'server_time',  now())
  from patients);
end $$;

-- ------------------------------------------------------------------ Đánh dấu đã khám / đã nộp hồ sơ
-- Thao tác nguyên tử: máy nào đến trước thì thắng, máy đến sau nhận lại đúng giờ của máy trước (status = 'already').
create or replace function public.mark_examined(p_key text, p_ma_nv text, p_device text, p_at timestamptz default null) returns jsonb
language plpgsql security definer set search_path = public, extensions as $$
declare r patients; code text := upper(btrim(p_ma_nv)); t timestamptz := least(coalesce(p_at, now()), now()); old_sub timestamptz; sub_reset boolean := false;
begin
  perform fn_check_key(p_key);
  select submitted_at into old_sub from patients where ma_nv = code;
  -- Khám lại: giờ khám mới muộn hơn giờ nộp hồ sơ cũ => đặt lại trạng thái nộp hồ sơ (giờ nộp luôn phải SAU giờ bắt đầu khám).
  sub_reset := old_sub is not null and old_sub < t;
  update patients set examined_at = t, examined_by = p_device,
         submitted_at = case when sub_reset then null else submitted_at end,
         submitted_by = case when sub_reset then null else submitted_by end,
         updated_at = now()
   where ma_nv = code and examined_at is null returning * into r;
  if found then
    return jsonb_build_object('status','ok','at',r.examined_at,'ho_ten',r.ho_ten,'submitted',r.submitted_at is not null,'submission_reset',sub_reset);
  end if;
  select * into r from patients where ma_nv = code;
  if not found then return jsonb_build_object('status','not_found'); end if;
  return jsonb_build_object('status','already','at',r.examined_at,'ho_ten',r.ho_ten,'submitted',r.submitted_at is not null,'submission_reset',false);
end $$;

create or replace function public.mark_submitted(p_key text, p_ma_nv text, p_device text, p_at timestamptz default null) returns jsonb
language plpgsql security definer set search_path = public, extensions as $$
declare r patients; code text := upper(btrim(p_ma_nv));
begin
  perform fn_check_key(p_key);
  -- Giờ nộp hồ sơ không bao giờ sớm hơn giờ bắt đầu khám (kể cả khi lệnh quét được lưu tạm lúc mất mạng).
  update patients set submitted_at = least(greatest(coalesce(p_at, now()), coalesce(examined_at, '-infinity'::timestamptz)), now()), submitted_by = p_device, updated_at = now()
   where ma_nv = code and submitted_at is null returning * into r;
  if found then
    return jsonb_build_object('status','ok','at',r.submitted_at,'ho_ten',r.ho_ten,'examined',r.examined_at is not null);
  end if;
  select * into r from patients where ma_nv = code;
  if not found then return jsonb_build_object('status','not_found'); end if;
  return jsonb_build_object('status','already','at',r.submitted_at,'ho_ten',r.ho_ten,'examined',r.examined_at is not null);
end $$;

create or replace function public.unmark_examined(p_key text, p_ma_nv text, p_device text, p_at timestamptz default null) returns jsonb
language plpgsql security definer set search_path = public, extensions as $$
declare code text := upper(btrim(p_ma_nv));
begin
  perform fn_check_key(p_key);
  update patients set examined_at = null, examined_by = null, updated_at = now() where ma_nv = code;
  if not found then return jsonb_build_object('status','not_found'); end if;
  return jsonb_build_object('status','ok');
end $$;

create or replace function public.unmark_submitted(p_key text, p_ma_nv text, p_device text, p_at timestamptz default null) returns jsonb
language plpgsql security definer set search_path = public, extensions as $$
declare code text := upper(btrim(p_ma_nv));
begin
  perform fn_check_key(p_key);
  update patients set submitted_at = null, submitted_by = null, updated_at = now() where ma_nv = code;
  if not found then return jsonb_build_object('status','not_found'); end if;
  return jsonb_build_object('status','ok');
end $$;

-- Gộp Loại BN khi một nhân viên xuất hiện ở nhiều lần import (ví dụ mỗi sheet một loại): có cả nghề nghiệp lẫn định kỳ => "cả hai".
create or replace function public.merge_loai_bn(a text, b text) returns text
language sql immutable as $$
  select case
    when w and p then 'Khám Nghề Nghiệp + Khám Định Kỳ'
    when w then 'Khám Nghề Nghiệp'
    when p then 'Khám Định Kỳ'
    else coalesce(nullif(btrim(b), ''), nullif(btrim(a), ''))
  end
  from (select (lower(coalesce(a,'')) like '%nghề nghiệp%' or lower(coalesce(b,'')) like '%nghề nghiệp%') as w,
               (lower(coalesce(a,'')) like '%định k_%'      or lower(coalesce(b,'')) like '%định k_%')      as p) f
$$;

-- Gộp danh sách dịch vụ thực hiện ("dich_vu" trong cột extra) khi một nhân viên xuất hiện ở nhiều lần import (ví dụ mỗi sheet một loại khám).
create or replace function public.merge_dich_vu(a jsonb, b jsonb) returns jsonb
language sql immutable as $$
  select coalesce(jsonb_agg(v order by array_position(array['XQ Phổi','HH','CSTL','TL','Đo nhãn áp','Điện tim','HBCO','TSTC','vgB,C','ALBUMIN','PH da','HIV','AFB'], v), v), '[]'::jsonb)
  from (select distinct jsonb_array_elements_text(
          case when jsonb_typeof(a) = 'array' then a else '[]'::jsonb end || case when jsonb_typeof(b) = 'array' then b else '[]'::jsonb end) as v) t
$$;

-- ------------------------------------------------------------------ Thêm bệnh nhân thủ công (từ app hoặc web)
-- Kiểm tra trùng STT / Mã NV / CCCD (chỉ đọc), dùng để cảnh báo ngay khi đang nhập.
create or replace function public.check_patient_duplicates(p_key text, p_stt integer, p_ma_nv text, p_cccd text) returns jsonb
language plpgsql security definer set search_path = public, extensions as $$
declare r jsonb := '[]'::jsonb; x record;
begin
  perform fn_check_key(p_key);
  if nullif(btrim(coalesce(p_ma_nv, '')), '') is not null then
    select stt, ho_ten into x from patients where ma_nv = upper(btrim(p_ma_nv)) limit 1;
    if found then r := r || jsonb_build_array(jsonb_build_object('field', 'ma_nv', 'stt', x.stt, 'ho_ten', x.ho_ten)); end if;
  end if;
  if p_stt is not null then
    select ma_nv, ho_ten into x from patients where stt = p_stt limit 1;
    if found then r := r || jsonb_build_array(jsonb_build_object('field', 'stt', 'ma_nv', x.ma_nv, 'ho_ten', x.ho_ten)); end if;
  end if;
  if nullif(btrim(coalesce(p_cccd, '')), '') is not null then
    select ma_nv, ho_ten into x from patients where cccd = btrim(p_cccd) limit 1;
    if found then r := r || jsonb_build_array(jsonb_build_object('field', 'cccd', 'ma_nv', x.ma_nv, 'ho_ten', x.ho_ten)); end if;
  end if;
  return jsonb_build_object('duplicates', r);
end $$;

-- Thêm một bệnh nhân mới. Trùng Mã NV: từ chối. Trùng STT hoặc CCCD: trả về cảnh báo, chỉ thêm khi p_force = true.
-- Không đụng tới bệnh nhân đã có (kể cả trạng thái đã phát / đã nộp hồ sơ).
create or replace function public.add_patient(p_key text, p_row jsonb, p_force boolean default false, p_device text default null) returns jsonb
language plpgsql security definer set search_path = public, extensions as $$
declare
  v_stt integer := nullif(btrim(coalesce(p_row->>'stt', '')), '')::integer;
  v_code text := upper(btrim(coalesce(p_row->>'ma_nv', '')));
  v_name text := btrim(coalesce(p_row->>'ho_ten', ''));
  v_cccd text := nullif(btrim(coalesce(p_row->>'cccd', '')), '');
  v_dup jsonb;
  v_services jsonb := case when jsonb_typeof(p_row->'dich_vu') = 'array' then p_row->'dich_vu' else '[]'::jsonb end;
begin
  perform fn_check_key(p_key);
  if v_stt is null or v_stt <= 0 then return jsonb_build_object('status', 'invalid', 'message', 'Thiếu STT hợp lệ'); end if;
  if v_code = '' then return jsonb_build_object('status', 'invalid', 'message', 'Thiếu Mã NV'); end if;
  if v_name = '' then return jsonb_build_object('status', 'invalid', 'message', 'Thiếu họ và tên'); end if;
  if v_cccd is not null and v_cccd !~ '^[0-9]{9}$' and v_cccd !~ '^[0-9]{12}$' then
    return jsonb_build_object('status', 'invalid', 'message', 'CCCD phải có 9 hoặc 12 chữ số');
  end if;

  v_dup := public.check_patient_duplicates(p_key, v_stt, v_code, v_cccd)->'duplicates';
  if exists (select 1 from jsonb_array_elements(v_dup) d where d->>'field' = 'ma_nv') then
    return jsonb_build_object('status', 'duplicate_ma_nv', 'duplicates', v_dup);
  end if;
  if jsonb_array_length(v_dup) > 0 and not coalesce(p_force, false) then
    return jsonb_build_object('status', 'duplicates', 'duplicates', v_dup);
  end if;

  insert into patients (stt, ma_nv, ho_ten, gioi_tinh, ngay_sinh, cong_ty, cccd, qr_code, don_nhan_ap, dien_tim, loai_bn, extra)
  values (v_stt, v_code, v_name, nullif(btrim(coalesce(p_row->>'gioi_tinh', '')), ''), nullif(p_row->>'ngay_sinh', '')::date,
          nullif(btrim(coalesce(p_row->>'cong_ty', '')), ''), v_cccd, v_code,
          case when v_services ? 'Đo nhãn áp' then 'X' end, case when v_services ? 'Điện tim' then 'X' end,
          nullif(btrim(coalesce(p_row->>'loai_bn', '')), ''),
          jsonb_build_object('dich_vu', v_services, 'nhap_thu_cong', true, 'nhap_boi', coalesce(p_device, '')));
  return jsonb_build_object('status', 'created', 'ma_nv', v_code);
end $$;

-- ------------------------------------------------------------------ Import từ app (theo lô)
-- Chỉ cập nhật thông tin hành chính. Trạng thái đã khám / đã nộp hiện có trên Supabase KHÔNG bị xóa;
-- nếu Excel có sẵn trạng thái (examined_at / submitted_at) thì chỉ bổ sung khi trên Supabase còn trống.
create or replace function public.import_patients(p_key text, p_rows jsonb) returns jsonb
language plpgsql security definer set search_path = public, extensions as $$
declare r jsonb; ins int := 0; upd int := 0; same int := 0; was_insert boolean; ex timestamptz; sb timestamptz;
begin
  perform fn_check_key(p_key);
  for r in select * from jsonb_array_elements(p_rows) loop
    was_insert := null;
    ex := nullif(r->>'examined_at','')::timestamptz;
    sb := nullif(r->>'submitted_at','')::timestamptz;
    if ex is not null and sb is not null and sb < ex then sb := null; end if;   -- giờ nộp hồ sơ phải SAU giờ bắt đầu khám
    insert into patients as p (stt, ma_nv, ho_ten, gioi_tinh, ngay_sinh, tuoi, cong_ty, cccd, qr_code, don_nhan_ap, dien_tim, extra, loai_bn,
                               examined_at, examined_by, submitted_at, submitted_by)
    values (nullif(r->>'stt','')::int, upper(btrim(r->>'ma_nv')), btrim(r->>'ho_ten'), nullif(btrim(r->>'gioi_tinh'),''),
            nullif(r->>'ngay_sinh','')::date, nullif(r->>'tuoi','')::int, nullif(btrim(r->>'cong_ty'),''), nullif(btrim(r->>'cccd'),''),
            nullif(btrim(r->>'qr_code'),''), nullif(btrim(r->>'don_nhan_ap'),''), nullif(btrim(r->>'dien_tim'),''),
            coalesce(r->'extra','{}'::jsonb), nullif(btrim(r->>'loai_bn'),''),
            ex, case when ex is not null then 'Excel' end,
            sb, case when sb is not null then 'Excel' end)
    on conflict (ma_nv) do update set
      stt = excluded.stt, ho_ten = excluded.ho_ten, gioi_tinh = excluded.gioi_tinh, ngay_sinh = excluded.ngay_sinh,
      tuoi = excluded.tuoi, cong_ty = excluded.cong_ty, cccd = excluded.cccd, qr_code = excluded.qr_code,
      don_nhan_ap = excluded.don_nhan_ap, dien_tim = excluded.dien_tim,
      extra = case when jsonb_typeof(excluded.extra->'dich_vu') = 'array'
                   then (p.extra || excluded.extra) || jsonb_build_object('dich_vu', public.merge_dich_vu(p.extra->'dich_vu', excluded.extra->'dich_vu'))
                   else p.extra || excluded.extra end,
      loai_bn = public.merge_loai_bn(p.loai_bn, excluded.loai_bn),   -- gộp: đã có nghề nghiệp + import định kỳ (hoặc ngược lại) => cả hai
      examined_at  = coalesce(p.examined_at,  excluded.examined_at),
      examined_by  = case when p.examined_at  is null then excluded.examined_by  else p.examined_by  end,
      submitted_at = case when coalesce(p.submitted_at, excluded.submitted_at) < coalesce(p.examined_at, excluded.examined_at) then null
                          else coalesce(p.submitted_at, excluded.submitted_at) end,
      submitted_by = case when coalesce(p.submitted_at, excluded.submitted_at) < coalesce(p.examined_at, excluded.examined_at) then null
                          when p.submitted_at is null then excluded.submitted_by else p.submitted_by end,
      updated_at = now()
    where (p.stt, p.ho_ten, p.gioi_tinh, p.ngay_sinh, p.tuoi, p.cong_ty, p.cccd, p.qr_code, p.don_nhan_ap, p.dien_tim, p.extra)
          is distinct from (excluded.stt, excluded.ho_ten, excluded.gioi_tinh, excluded.ngay_sinh, excluded.tuoi, excluded.cong_ty,
                            excluded.cccd, excluded.qr_code, excluded.don_nhan_ap, excluded.dien_tim, p.extra || excluded.extra)
       or p.loai_bn is distinct from public.merge_loai_bn(p.loai_bn, excluded.loai_bn)
       or (jsonb_typeof(excluded.extra->'dich_vu') = 'array' and p.extra->'dich_vu' is distinct from public.merge_dich_vu(p.extra->'dich_vu', excluded.extra->'dich_vu'))
       or (p.examined_at  is null and excluded.examined_at  is not null)
       or (p.submitted_at is null and excluded.submitted_at is not null)
    returning (xmax = 0) into was_insert;
    if was_insert is null then same := same + 1;
    elsif was_insert then ins := ins + 1;
    else upd := upd + 1;
    end if;
  end loop;
  return jsonb_build_object('inserted', ins, 'updated', upd, 'unchanged', same);
end $$;

-- ------------------------------------------------------------------ Phân quyền hàm
-- Hàm quản trị: KHÔNG cho khóa công khai gọi.
revoke all on function public.set_access_key(text) from public, anon, authenticated;
revoke all on function public.fn_check_key(text)   from public, anon, authenticated;
-- Hàm app dùng: cho phép khóa công khai (anon) gọi, mỗi hàm tự kiểm tra mã truy cập.
grant execute on function public.list_patients(text)                              to anon, authenticated;
grant execute on function public.get_changes(text, timestamptz)                   to anon, authenticated;
grant execute on function public.get_stats(text)                                  to anon, authenticated;
grant execute on function public.mark_examined(text, text, text, timestamptz)     to anon, authenticated;
grant execute on function public.mark_submitted(text, text, text, timestamptz)    to anon, authenticated;
grant execute on function public.unmark_examined(text, text, text, timestamptz)   to anon, authenticated;
grant execute on function public.unmark_submitted(text, text, text, timestamptz)  to anon, authenticated;
grant execute on function public.import_patients(text, jsonb)                     to anon, authenticated;
grant execute on function public.check_patient_duplicates(text, integer, text, text) to anon, authenticated;
grant execute on function public.add_patient(text, jsonb, boolean, text)           to anon, authenticated;

-- ------------------------------------------------------------------ ĐẶT MÃ TRUY CẬP  (ĐỔI giá trị trong dấu nháy trước khi chạy!)
select public.set_access_key('DOI-MA-NAY-TRUOC-KHI-CHAY');
